Page({
  globalData: {
    encryptedData: null,
    iv: null,
    session: null
  },
  onLoad: function () {
    var that= this
    wx.login({
    success: function (res) {
      if (res.code) {
        //发起session网络请求
        wx.request({
          url: 'https://zjite.applinzi.com/api/openid.php',
          header: {
            'content-type': 'application/json'
          },
          data: {
            code: res.code
          },
          success: function (res) {
            that.globalData.session = res.data.session_key
            console.log(that.globalData.session) 
          }
        })
        var that = this
        wx.getWeRunData({
          success(res) {
            var that = this
            wx.request({
              url: 'https://zjite.applinzi.com/api/sport/demo.php',
              header: {
                'content-type': 'application/json'
              },
              data: {
                sessionKey: that.globalData.session,
                iv: that.globalData.iv,
                encryptedData: that.globalData.encryptedData
              },
              success: function (res) {
                // console.log(res);
                console.log(res.data);
                //console.log(res.data);
              }
            })
          }
        })
      }
    }
  });
  }
})