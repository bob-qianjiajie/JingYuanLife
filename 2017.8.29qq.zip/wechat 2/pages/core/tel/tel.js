// pages/core/shangke/shangke.js
Page({
  data: {
    listData: [
      { "code": "教务科", "text":"86928019"},
      { "code": "教学科", "text":"86923316"},
      { "code": "实践教学与技能考证科", "text":"86928030"},
      { "code": "教学数据科", "text":"86928026"},
    { "code":"【备注】", "text":"", "type":"玩转经院"}
  ]
  },
  onLoad: function () {
      console.log('onLoad')
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})