// pages/core/shangke/shangke.js
Page({
  data: {
    listData: [
    { "code":"【上午】第一节", "text":"8:10", "type":"8:50"},
    { "code":"【上午】第二节", "text":"8:55", "type":"9:35"},
    { "code":"【上午】第三节", "text":"9:50", "type":"10:30"},
    { "code":"【上午】第四节", "text":"10:35", "type":"11:15"},
    { "code":"【上午】第五节", "text":"11:20", "type":"12:00"},
    { "code":"【下午】第一节", "text":"13:40", "type":"14:20"},
    { "code":"【下午】第二节", "text": "14:25", "type": "15:05" },
    { "code":"【下午】第三节", "text": "15:20", "type": "16:00" },
    { "code":"【下午】第四节", "text": "16:05", "type": "16:45" },
    { "code":"【晚上】第一节", "text": "18:00", "type": "18:40" },
    { "code":"【晚上】第二节", "text": "18:45", "type": "19:25" },
    { "code":"【晚上】第三节", "text": "19:30", "type": "20:10" },
    { "code":"【备注】", "text":"法定节假日以政府同意规定", "type":"玩转经院"}
  ]
  },
  onLoad: function () {
      console.log('onLoad')
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})