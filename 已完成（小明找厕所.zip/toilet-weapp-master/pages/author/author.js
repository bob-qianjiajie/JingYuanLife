//获取应用实例
var app = getApp()
Page({
  // 数据
  data: {
  },
  // 页面加载
  onLoad: function () {
  }
})